### ARP протокол + ARP spoofing

[https://ru.wikipedia.org/wiki/ARP-spoofing](https://ru.wikipedia.org/wiki/ARP-spoofing "smartCard-inline")

[https://ru.wikipedia.org/wiki/ARP](https://ru.wikipedia.org/wiki/ARP "smartCard-inline")

[https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%B0%D0%BA%D0%B0_%D0%BF%D0%BE%D1%81%D1%80%D0%B5%D0%B4%D0%BD%D0%B8%D0%BA%D0%B0](https://ru.wikipedia.org/wiki/%D0%90%D1%82%D0%B0%D0%BA%D0%B0_%D0%BF%D0%BE%D1%81%D1%80%D0%B5%D0%B4%D0%BD%D0%B8%D0%BA%D0%B0 "smartCard-inline")

[https://habr.com/ru/company/varonis/blog/562144/](https://habr.com/ru/company/varonis/blog/562144/ "smartCard-inline")
